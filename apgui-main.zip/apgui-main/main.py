from allportals import AllPortals


def main():
    app = AllPortals()
    app.start()


if __name__ == "__main__":
    main()
