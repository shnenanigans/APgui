mydict = {2: "hi", 1: "no", 0: "yes"}
for thing in mydict.values():
    print(thing)